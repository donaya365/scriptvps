#!/bin/bash

clear
echo -e "================================================="
echo -e "#         PREMIUM AUTO SCRIPT BY ENVY PROJECTS         #"
echo -e "================================================="
echo -e "# For Debian 9 & Debian 10 64 bit               #"
echo -e "# For Ubuntu 18.04 & Ubuntu 20.04 64 bit        #"
echo -e "# For VPS with KVM and VMWare virtualization    #"
echo -e "# BUILD UP BY ENVY PROJECTS                            #"
echo -e "================================================="
echo -e "# THANKS TO                                     #"
echo -e "================================================="
echo -e "# ALLAH SWT                                     #"
echo -e "# MY FAMILY                                     #"
echo -e "# ENVY PROJECTS                                        #"
echo -e "# HORASSS                                       #"
echo -e "================================================="
